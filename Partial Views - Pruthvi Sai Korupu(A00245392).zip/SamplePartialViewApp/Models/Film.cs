﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SamplePartialViewApp.Models
{
    public class Film
    {
        public string FilmName { get; set; }
        public string Duration { get; set; }
        public string Description { get; set; }
    }
}
